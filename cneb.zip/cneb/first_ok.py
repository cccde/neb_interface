the_num = 0
f = open("decision", 'w')
f.write("True\n")
f.write(str(the_num))
f.close()
